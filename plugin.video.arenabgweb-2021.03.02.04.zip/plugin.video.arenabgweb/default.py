# -*- coding: utf-8 -*-
import re
import sys
import xbmc, xbmcplugin,xbmcgui,xbmcaddon
import urllib
try:
    import urllib2
except:
    pass
import base64
import os
import codecs
import unicodedata
import time
import json
import requests
import urllib3
from bs4 import BeautifulSoup
try:
    import xbmcvfs
except:
    pass

KodiV = xbmc.getInfoLabel('System.BuildVersion')
KodiV = int(KodiV[:2])

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

__addon_id__= 'plugin.video.arenabgweb'
__Addon = xbmcaddon.Addon(__addon_id__)
try:
    __icon_search__ = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/search.png")
    __icon_folders__ = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/movie.png")
    __icon_fav__ = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/fav.png")
    __icon_latests__ = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/latests.png")
    __icon_emptyfolder__ = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/empty.png")
    __icon__ =  xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/icon.png")
    __icon_clear__ = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/clear.png")
    __icon_sresult__ = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/search-result.png")
    __icon_nextpage__ = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/next-page.png")
except:
    __icon_search__ = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/search.png")
    __icon_folders__ = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/movie.png")
    __icon_fav__ = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/fav.png")
    __icon_latests__ = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/latests.png")
    __icon_emptyfolder__ = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/empty.png")
    __icon__ =  xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/icon.png")
    __icon_clear__ = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/clear.png")
    __icon_sresult__ = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/search-result.png")
    __icon_nextpage__ = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/next-page.png")

searchlist = __Addon.getSetting('searchlist')
player = __Addon.getSetting('tplayer')

def Notify (msg1, msg2):
    try:
        xbmc.executebuiltin((u'Notification(%s,%s,%s,%s)' % (msg1, msg2, '5000', __icon__)).encode('utf-8'))
    except:
        xbmc.executebuiltin((u'Notification(%s,%s,%s,%s)' % (msg1, msg2, '5000', __icon__)))

if (__Addon.getSetting('firstrun') == 'true'):
    Notify('Settings', 'empty')
    __Addon.openSettings()
    __Addon.setSetting('firstrun', 'false')
    
if __Addon.getSetting('xxx') == 'true':
    xxx = True
    sub_url = '&categories%5B%5D=8&categories%5B%5D=9&categories%5B%5D=10&categories%5B%5D=11&categories%5B%5D=12&categories%5B%5D=13&categories%5B%5D=14&categories%5B%5D=15&categories%5B%5D=16&categories%5B%5D=17&categories%5B%5D=18&categories%5B%5D=19&categories%5B%5D=20&categories%5B%5D=21&categories%5B%5D=22&categories%5B%5D=23&categories%5B%5D=24&categories%5B%5D=25&categories%5B%5D=26&categories%5B%5D=28&categories%5B%5D=52&categories%5B%5D=53'
else:
    xxx = False
    sub_url = '&categories%5B%5D=8&categories%5B%5D=9&categories%5B%5D=10&categories%5B%5D=11&categories%5B%5D=12&categories%5B%5D=13&categories%5B%5D=14&categories%5B%5D=15&categories%5B%5D=16&categories%5B%5D=17&categories%5B%5D=18&categories%5B%5D=19&categories%5B%5D=20&categories%5B%5D=21&categories%5B%5D=22&categories%5B%5D=23&categories%5B%5D=24&categories%5B%5D=25&categories%5B%5D=26&categories%5B%5D=28'

if not __Addon.getSetting('username'):
    Notify('User', 'empty')
else:
    arenauser = __Addon.getSetting('username')
if not __Addon.getSetting('password'):
    Notify('Password', 'empty')
else:
    arenapass = __Addon.getSetting('password')

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36'

s = requests.Session()
baseurl = 'https://arenabg.com'
torrenturl = baseurl + '/bg/torrents/'
favurl = torrenturl + '?favorites'
headers_new = {'user-agent': UA}


lurl = baseurl + '/bg/users/signin/'
values = {'username_or_email' : arenauser,
          'password' : arenapass }

r = s.post(lurl, data=values, headers=headers_new)
if r.status_code == requests.codes.ok and re.search(arenauser, r.text, re.IGNORECASE):
    pass
else:
    Notify('Login Fail!', 'Check username or password')
    raise Exception("LoginFail")

def CATEGORIES():
    addDir('Търсене',baseurl,2,__icon_search__)
    addDir('Любими',favurl,1,__icon_fav__)
    addDir('Последно добавени',torrenturl,1,__icon_latests__)
    
    r = s.get(torrenturl, headers=headers_new)
    data = r.text
    soup = BeautifulSoup(data, "html.parser")
    divs = soup.find_all('div', attrs={'id': 'torrents-categories'})
    div = divs[0]
    match = re.compile('<a href="(.+?)">(.+?)</a>').findall(str(div))
    
    checkfilmi = 0
    filmititle = '[B] [I] [COLOR CC00FF00]ФИЛМИ[/COLOR] [/I] [/B]'
    checkseriali = 0
    serialititle = '[B] [I] [COLOR CC00FF00]СЕРИАЛИ[/COLOR] [/I] [/B]'
    checkxxx = 0
    xxxtitle = '[B] [I] [COLOR CC00FF00]XXX[/COLOR] [/I] [/B]'
    
    thumbnail = __icon_folders__
    for link, title in match:
        catidsplit = link.split('=')
        catid = int(catidsplit[1])
        
        if catid > 7 and catid < 23:
            if checkfilmi == 0:
                addDir(filmititle,'',1,__icon_emptyfolder__)
                checkfilmi = 1
            else:
                pass
            newlink = baseurl + link
            addDir(title,newlink,1,thumbnail)
        else:
            pass
        
        if catid > 22 and catid < 27:
            if checkseriali == 0:
                addDir(serialititle,'',1,__icon_emptyfolder__)
                checkseriali = 1
            else:
                pass
            newlink = baseurl + link
            addDir(title,newlink,1,thumbnail)
        else:
            pass
            
        if xxx:
            if catid > 51 and catid < 54:
                if checkxxx == 0:
                    addDir(xxxtitle,'',1,__icon_emptyfolder__)
                    checkxxx = 1
                else:
                    pass
                newlink = baseurl + link
                addDir(title,newlink,1,thumbnail)
            else:
                pass


def INDEXPAGES(url):
    caturl = url
    r = s.get(caturl, headers=headers_new)
    data = r.text
    soup = BeautifulSoup(data, "html.parser")
    divs = soup.find_all('div', attrs={'class': 'position-relative'})

    for div in divs:
        searchcat = re.search('category=(.+?)"',str(div))
        if searchcat:
            checkcat = int(searchcat.group(1))
            if checkcat == 1 or checkcat == 2 or (xxx and checkcat == 6):
                desk = ''
                linkmatch = re.search('class="title" href="(.+?)"', str(div))
                link = baseurl + linkmatch.group(1)
                r_url = s.get(link, headers=headers_new)
                data_url = r_url.text
                try:
                    linksearch = re.search('<a href="(magnet.+?)"', str(data_url))
                except:
                    linksearch = re.search('<a href="(magnet.+?)"', data_url)
                if linksearch:
                    playlink = linksearch.group(1)
                    playlink = playlink.replace('&amp;','&').replace(' ','%20').encode("utf-8")
                    data_url = data_url.replace('\n','').replace('\t','').encode("utf-8")
                    try:
                        findjanr = re.search('Жанр.+?>(.+?)<br', str(data_url.decode('utf8')),re.U)
                    except:
                        findjanr = re.search('Жанр.+?>(.+?)<br', data_url)
                    if findjanr:
                        desk = desk + '[COLOR CC00FF00]Жанр: [/COLOR]'+ findjanr.group(1).strip() + '\n'
                    try:
                        findsize = re.search('Размер.+?col-9">(.+?)</div>', str(data_url.decode('utf8')),re.U)
                    except:
                        findsize = re.search('Размер.+?col-9">(.+?)</div>', data_url)
                    if findsize:
                        desk = desk + '\n[COLOR CC00FF00]Размер: [/COLOR]'+ findsize.group(1) + '\n'
                    try:
                        findseed = re.search('пийъри.+?col-9">(.+?)</div>', str(data_url.decode('utf8')),re.U)
                    except:
                        findseed = re.search('пийъри.+?col-9">(.+?)</div>', data_url)
                    if findseed:
                        seedsplit = findseed.group(1).split(', ')
                        try:
                            desk = desk + '[COLOR CC00FF00]Сийдъри: [/COLOR]'+ str(seedsplit[0])
                            desk = desk + '\n[COLOR CC00FF00]Пийъри: [/COLOR]'+ str(seedsplit[1]) + '\n'
                        except:
                            try:
                                desk = desk + '[COLOR CC00FF00]Сийдъри: [/COLOR]'+ str(seedsplit[0]) + '\n'
                            except:
                                desk = desk + '[COLOR CC00FF00]Пийъри: [/COLOR]'+ str(seedsplit[1]) + '\n'
                    thumbmatch = re.search('hovershow\("(.+?)"\)', str(div))
                    thumb = thumbmatch.group(1).replace('\/','/')
                    divrep = str(div).replace('\n','').replace('\t','')
                    titlematch = re.search('hovershow\(".+?"\);\'\>(.+?)</a>', str(divrep))
                    title = titlematch.group(1)
                    title = title.replace('&amp;','&')
                    titleor = title
                    checkBGsub = re.search('alt="BG"',divrep)
                    if checkBGsub:
                        title = title +'[COLOR CC00FF00] | BG Subs[/COLOR]'
                        desk = desk + '\n[COLOR CC00FF00]BG Subs[/COLOR]'
                    else:
                        pass
                    checkAudio = re.search('volume.+?title="(.+?)">',divrep)
                    if checkAudio:
                        title = title +"[COLOR CC00FF00] | "+ checkAudio.group(1) + "[/COLOR]"
                        desk = desk + '\n[COLOR CC00FF00]'+ checkAudio.group(1) + '[/COLOR]'
                    else:
                        pass
                    #намираме IMDB ID
                    matchimdb = re.search('imdb.com/title/(.+?)"', str(data_url))
                    if matchimdb:
                        imdb_id = matchimdb.group(1)
                    else:
                        imdb_id = ""
                    #край на намирането
                    addLink(title,playlink,3,desk,thumb,titleor,imdb_id)
                else:
                    pass
            else:
                pass
    searchpage = re.search('class="page-item  active">.+?href="(.+?)(\d)">', data)
    if searchpage:
        numb = int(searchpage.group(2)) + 1
        nextpage = baseurl + searchpage.group(1) + str(numb)
        nextpage = nextpage.replace('&amp;','&')
        addDir('[COLOR CC00FF00] [B] [I]Следваща страница >>>[/I] [/B] [/COLOR]',nextpage,1,__icon_nextpage__)
    else:
        pass                
         
def SEARCHPAGE(url):
    addDir('[COLOR CC00FF00]  Търсене[/COLOR]',baseurl,4,__icon_search__)
    if searchlist == '':
        pass
    else:
        templist = searchlist[:-1]
        matchsearch = templist.split(';')
        for title in matchsearch:
            searchText = str(title).replace(' ','+')
            searchurl = torrenturl + '?text=' + searchText + sub_url
            addDir(str(title),searchurl,1,__icon_sresult__)
    addDir('[COLOR CC00FF00]  Изчисти търсенето[/COLOR]',baseurl,5,__icon_clear__)

def SEARCH(url):
    keyb = xbmc.Keyboard('', 'Търсачка')
    keyb.doModal()
    searchText = ''
    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0 :
        try:
            searchText = urllib.quote_plus(keyb.getText())
        except:
            searchText = urllib.parse.quote_plus(keyb.getText())
        if KodiV >= 19:
            pass
        else:
            searchText = searchText.encode('utf-8')
        searchText = searchText.replace('+',' ')
        __Addon.setSetting('searchlist', searchText + ';' + searchlist)
        searchText = searchText.replace(' ','+')
        searchurl = torrenturl + '?text=' + searchText + sub_url
        INDEXPAGES(searchurl)
    else:
        xbmc.executebuiltin('Action(ParentDir)')


def PLAY(url):
    playlink = url
    
    if '0' in player:
        p = 'plugin://plugin.video.quasar/play?uri=%s' % (playlink)
    if '1' in player:
        p = 'plugin://plugin.video.elementum/play?uri=%s' % (playlink)
    li = xbmcgui.ListItem(path=p)
    try:
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
    except:
        xbmc.executebuiltin("Notification('Грешка','Няма достъп до източника!')")


def addLink(name,url,mode,plot,iconimage,nameor,imdbid):
        try:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&plot="+urllib.quote_plus(plot)+"&iconimage="+urllib.quote_plus(iconimage)+"&nameor="+urllib.quote_plus(nameor)+"&imdbid="+urllib.quote_plus(imdbid)
        except:
            u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&plot="+urllib.parse.quote_plus(plot)+"&iconimage="+urllib.parse.quote_plus(iconimage)+"&nameor="+urllib.parse.quote_plus(nameor)+"&imdbid="+urllib.parse.quote_plus(imdbid)
        ok=True
        try:
            liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        except:
            liz=xbmcgui.ListItem(name)
        liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
        liz.setInfo( type="Video", infoLabels={ "Title": nameor, "plot": plot, 'IMDBNumber': imdbid } )
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def addDir(name,url,mode,iconimage):
        try:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        except:
            u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
        ok=True
        try:
            liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        except:
            liz=xbmcgui.ListItem(name)
        liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param







params=get_params()
url=None
name=None
iconimage=None
plot=None
mode=None
nameor=None
imdbid=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        try:
                url=urllib.parse.unquote_plus(params["url"])
        except:
                pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        try:
                name=urllib.parse.unquote_plus(params["name"])
        except:
                pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        try:
                iconimage=urllib.parse.unquote_plus(params["iconimage"])
        except:
                pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        plot=urllib.unquote_plus(params["plot"])
except:
        try:
                plot=urllib.parse.unquote_plus(params["plot"])
        except:
                pass
try:
        nameor=urllib.unquote_plus(params["nameor"])
except:
        try:
                nameor=urllib.parse.unquote_plus(params["nameor"])
        except:
                pass
try:
        imdbid=urllib.unquote_plus(params["imdbid"])
except:
        try:
                imdbid=urllib.parse.unquote_plus(params["imdbid"])
        except:
                pass



if mode==None or url==None or len(url)<1:
        print ("")
        CATEGORIES()
    
elif mode==1:
        print (""+url)
        INDEXPAGES(url)

elif mode==2:
        print (""+url)
        SEARCHPAGE(url)
        
elif mode==4:
        print (""+url)
        SEARCH(url)

elif mode==3:
        print (""+url)
        PLAY(url)
        
elif mode == 5:  
        __Addon.setSetting('searchlist', '')
        searchlist = __Addon.getSetting('searchlist')
        xbmc.executebuiltin('Action(ParentDir)')           

xbmcplugin.endOfDirectory(int(sys.argv[1]))
