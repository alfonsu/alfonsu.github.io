# -*- coding: utf-8 -*-

from nsub import log_my, savetofile, list_key
from common import *
import requests
import re
try:
  import urllib.request
except:
  pass
import json
import io

s = requests.Session()

values = {'s': '','y': '','u':'', 'l': 'BG','g': '', 'i': ''}

headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
'Accept-Encoding': 'gzip, deflate',
'Accept-Language': 'en-US,en;q=0.9,bg-BG;q=0.8,bg;q=0.7,ru;q=0.6',
'Connection': 'keep-alive',
'Host': 'yavka.net',
'Referer': 'http://yavka.net/subtitles.php',
'Upgrade-Insecure-Requests': '1',
'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'}

url = 'yavka.net'
url_full = 'https://yavka.net'

def get_id_url_n(txt, list):
  soup = BeautifulSoup(txt, 'html.parser')
  # dump_src(soup, 'src.html')
  for link in soup.findAll("a", {"class": "balon"}): 
    info = link.text
    yr = link.find_next_sibling('span', text=True)
    yr = yr.text.replace('(','').replace(')','')
    fps = link.find_all_next(string=True)[6].strip()
    try:
        tempurl = '/'+link['href'].encode('utf-8', 'replace').decode('utf-8')
        list.append({'url': tempurl.replace('//','/'),
                  'FSrc': '[COLOR CC00FF00][B][I](yavka) [/I][/B][/COLOR]',
                  'info': info.encode('utf-8', 'replace').decode('utf-8'),
                  'year': yr.encode('utf-8', 'replace').decode('utf-8'),
                  'cds': '',
                  'fps': fps.encode('utf-8', 'replace').decode('utf-8'),
                  'rating': '0.0',
                  'id': __name__})
    except:
        tempurl = '/'+link['href'].encode('utf-8', 'replace')
        list.append({'url': tempurl.replace('//','/'),
                  'FSrc': '[COLOR CC00FF00][B][I](yavka) [/I][/B][/COLOR]',
                  'info': info.encode('utf-8', 'replace'),
                  'year': yr.encode('utf-8', 'replace'),
                  'cds': '',
                  'fps': fps.encode('utf-8', 'replace'),
                  'rating': '0.0',
                  'id': __name__})
  return

def get_data(l, key):
  out = []
  for d in l:
    out.append(d[key])
  return out

def read_sub (mov, year):
  list = []
  log_my(mov, year)
  
  values['s'] = mov
  values['y'] = year
  
  try:
      enc_values = urllib.parse.urlencode(values)
  except:
      enc_values = urllib.urlencode(values)
  
  log_my('Url: ', (url), 'Headers: ', (headers), 'Values: ', (enc_values))

  try:
        connection = HTTPConnection(url)
  except:
        connection = http.client.HTTPConnection(url)
  connection.request("POST", "/subtitles.php?", headers=headers, body=enc_values)
  response = connection.getresponse()
  
  try:
    r = s.post(url_full+"/subtitles.php?"+enc_values, headers=headers)
    log_my(response.getheaders())
    data = r.text
  except:
    connection.close()
    return None

  get_id_url_n(data, list)
  if run_from_xbmc == False:
    for k in list_key:
      d = get_data(list, k)
      log_my(d)

  return list

def get_sub(id, sub_url, filename):
  ss = requests.Session()
  rID = ss.get(url_full + sub_url, headers=headers)
  #findID = re.search('name="id" value="(.+?)"', rID.text)
  findID = re.compile('type="hidden" name="(.+?)" value="(.+?)"').findall(rID.text)

  s = {}
  tsplit = sub_url.split('/')
  if findID:
        counID = 1
        for nam, val in findID:
            if counID == 1:
                nam2 = nam
                val2 = val
                counID = counID + 1
            else:
                nam1 = nam
                val1 = val
        tvalues = {nam1: val1,
                   nam2: val2}
  else:
        ID = tsplit[2]
        tvalues = {'id': ID,
                   'lng': tsplit[3] }

  try:
      enc_values = urllib.parse.urlencode(tvalues).encode("utf-8")
  except:
      enc_values = urllib.urlencode(tvalues)
  headers['Referer'] = url_full + sub_url

  try:
      request = urllib.request.Request(url_full + sub_url+'/', enc_values, headers)
      response = urllib.request.urlopen(request)
  except:
      request = urllib2.Request(url_full + sub_url+'/', enc_values, headers)
      response = urllib2.urlopen(request)
  s['data'] = response.read()
  s['fname'] = response.info()['Content-Disposition'].split('filename=')[1].strip('"')
  return s