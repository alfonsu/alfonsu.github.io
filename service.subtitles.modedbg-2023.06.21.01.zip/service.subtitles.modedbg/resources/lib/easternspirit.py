# -*- coding: utf-8 -*-

from nsub import log_my, savetofile, list_key
from common import *
import xbmcgui
import requests
import re
try:
  import urllib.request
except:
  pass
import json
import io

values = {'q': '','type': 'downloads_file','search_and_or': 'or','search_in': 'titles','sortby': 'relevancy'}

headers = {
    'Upgrade-Insecure-Requests' : '1',
    'User-Agent' : 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
    'Content-Type' : 'application/x-www-form-urlencoded',
    'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'Accept-Encoding': 'gzip, deflate',
    'Referer' : 'http://www.easternspirit.org/forum/index.php?/files/',
    'Accept-Language' : 'en-US,en;q=0.8'
}

url = 'http://www.easternspirit.org/forum'

KodiV = xbmc.getInfoLabel('System.BuildVersion')
KodiV = int(KodiV[:2])

def get_id_url_n(txt, list):
  soup = BeautifulSoup(txt, 'html.parser')
  for link in soup.find_all("span", class_="ipsContained ipsType_break"):
    #print link
    href = link.find('a', href=True)
    title = link.getText()
    title = re.sub('[\r\n]+','',title)
    yr =  re.search('.*\((\d+)',title).group(1)
    title = re.sub(' \(.*\s+','',title)
    
    try:
        list.append({'url': href['href'].encode('utf-8', 'replace').decode('utf-8'),
                  'FSrc': '[COLOR CC00FF00][B][I](eastern) [/I][/B][/COLOR]',
                  'info': title.encode('utf-8', 'replace').decode('utf-8'),
                  'year': yr.encode('utf-8', 'replace').decode('utf-8'),
                  'cds': '',
                  'fps': '',
                  'rating': '0.0',
                  'id': __name__})
    except:
        list.append({'url': href['href'].encode('utf-8', 'replace'),
                  'FSrc': '[COLOR CC00FF00][B][I](eastern) [/I][/B][/COLOR]',
                  'info': title.encode('utf-8', 'replace'),
                  'year': yr.encode('utf-8', 'replace'),
                  'cds': '',
                  'fps': '',
                  'rating': '0.0',
                  'id': __name__})
  return

def get_data(l, key):
  out = []
  for d in l:
    out.append(d[key])
  return out

def read_sub (mov):
  list = []

  values['q'] = mov
  
  try:
      enc_values = urllib.parse.urlencode(values)
      request = urllib.request.Request(url + '/index.php?/search/&'+enc_values.replace('+','%20'), None, headers)
  except:
      enc_values = urllib.urlencode(values)
      request = urllib2.Request(url + '/index.php?/search/&'+enc_values.replace('+','%20'), None, headers)

  try:
      response = urllib.request.urlopen(request)
  except:
      response = urllib2.urlopen(request)


  if response.info().get('Content-Encoding') == 'gzip':
    try:
        try:
            buf = StringIO(response.read())
        except:
            buf = io.BytesIO(response.read())
        f = gzip.GzipFile(fileobj=buf)
        data = f.read()            
        
        log_my(response.code)
        f.close()
        buf.close()
    except:
        try:
            response = urllib.request.urlopen(request)
        except:
            response = urllib2.urlopen(request)
        data = response.read() 
  else:
    if response.info().get('X-Content-Encoding-Over-Network') == 'gzip':
      try:
          try:
              buf = StringIO(response.read())
          except:
              buf = io.BytesIO(response.read())
          f = gzip.GzipFile(fileobj=buf)
          data = f.read()            
          
          log_my(response.code)
          f.close()
          buf.close()
      except:
          try:
              response = urllib.request.urlopen(request)
          except:
              response = urllib2.urlopen(request)
          data = response.read() 
    else:
      log_my('Error: ', response.info().get('X-Content-Encoding-Over-Network'))
      return None

  get_id_url_n(data, list)
  #if run_from_xbmc == False:
  for k in list_key:
      d = get_data(list, k)
      log_my(d)

  return list


        
def getResult(subs):
    IDs = [i[1] for i in subs]
    displays = [i[0] for i in subs]
    idx = xbmcgui.Dialog().select('Select subs',displays)
    if idx < 0: return None
    return IDs[idx]
      
def get_sub(id, sub_url, filename):
  try:
      request = urllib.request.Request(sub_url, None, headers)
      response = urllib.request.urlopen(request)
  except:
      request = urllib2.Request(sub_url, None, headers)
      response = urllib2.urlopen(request)
  mycook = response.info().get('Set-Cookie')
  if response.info().get('Content-Encoding') == 'gzip':
      try:
          try:
              buf = StringIO(response.read())
          except:
              buf = io.BytesIO(response.read())
          f = gzip.GzipFile(fileobj=buf) 
          data = f.read()
          f.close()
          buf.close()
      except:
          try:
              request = urllib.request.Request(sub_url, None, headers)
              response = urllib.request.urlopen(request)
          except:
              request = urllib2.Request(sub_url, None, headers)
              response = urllib2.urlopen(request)
          data = response.read()
  else:
      if response.info().get('X-Content-Encoding-Over-Network') == 'gzip':
          try:
              try:
                  buf = StringIO(response.read())
              except:
                  buf = io.BytesIO(response.read())
              f = gzip.GzipFile(fileobj=buf) 
              data = f.read()
              f.close()
              buf.close()
          except:
              try:
                  request = urllib.request.Request(sub_url, None, headers)
                  response = urllib.request.urlopen(request)
              except:
                  request = urllib2.Request(sub_url, None, headers)
                  response = urllib2.urlopen(request)
              data = response.read()
      else:
          data = response.read()
          log_my('Error: ', response.info().get('X-Content-Encoding-Over-Network'))

  if KodiV >= 19:
      match = re.findall("<a href='(.+?)' class='ipsButton ipsButton_fullWidth", data.decode('utf-8'))
  else:
      match = re.findall("<a href='(.+?)' class='ipsButton ipsButton_fullWidth", data)

  nexturl = match[0].replace('&amp;','&')
  dheaders = {
    'Upgrade-Insecure-Requests' : '1',
    'User-Agent' : 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
    'Content-Type' : 'application/x-www-form-urlencoded',
    'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'Referer' : 'http://www.easternspirit.org/forum/index.php?/files/',
    'Accept-Encoding' : 'gzip, deflate',
    'Accept-Language' : 'en-US,en;q=0.8',
    'Cookie': mycook,
    'Connection': 'keep-alive',
    'Referer': nexturl,
    'Host': 'www.easternspirit.org'
}
  
  try:
      request = urllib.request.Request(nexturl, None, dheaders)
  except:
      request = urllib2.Request(nexturl, None, dheaders)
  request.add_header('Cookie',mycook)
  try:
      response = urllib.request.urlopen(request)
  except:
      response = urllib2.urlopen(request)
  s = {} 
  if response.info().get('Content-Type') == 'application/x-rar-compressed':
    s['data'] = response.read()
    s['fname'] = response.info()['Content-Disposition'].split('filename=')[1].strip('"')
    return s
  else:
    #TV SERIES FIX
    if response.info().get('Content-Encoding') == 'gzip':
        try:
            try:
                buf = StringIO(response.read())
            except:
                buf = io.BytesIO(response.read())
            f = gzip.GzipFile(fileobj=buf)
            data2 = f.read()
            f.close()
            buf.close()
        except:
            try:
                response = urllib.request.urlopen(request)
            except:
                response = urllib2.urlopen(request)
            data2 = response.read()
    else:
      if response.info().get('X-Content-Encoding-Over-Network') == 'gzip':
          try:
              try:
                  buf = StringIO(response.read())
              except:
                  buf = io.BytesIO(response.read())
              f = gzip.GzipFile(fileobj=buf)
              data2 = f.read()
              f.close()
              buf.close()
          except:
              try:
                  response = urllib.request.urlopen(request)
              except:
                  response = urllib2.urlopen(request)
              data2 = response.read()
      else:
          data2 = response.read()
    
    if KodiV >= 19:
        data2 = data2.decode("utf-8")
    else:
        pass

    data2 = re.sub('[\r\n]+','',data2)
    data2 = re.sub('&amp;','&',data2)
        
    match = re.findall("ipsType_break ipsContained'>([^<>]+)<.+?a href='([^']+)'", data2)
    sub_url = getResult(match)
    try:
        request = urllib.request.Request(sub_url, None, dheaders)
    except:
        request = urllib2.Request(sub_url, None, dheaders)
    request.add_header('Cookie',mycook)
    try:
        response = urllib.request.urlopen(request)
    except:
        response = urllib2.urlopen(request)
    s['data'] = response.read()
    s['fname'] = response.info()['Content-Disposition'].split('filename=')[1].strip('"')
    return s
