import urllib.request
import zipfile
import shutil
import xbmcvfs
import os

urls = [
    'https://www.dropbox.com/scl/fi/u8rzl4d214hcwhxuthvle/kodi.zip?rlkey=rauhg1dodjc9gtxj597vrbbxz&dl=1'
]

extract_paths = [
    xbmcvfs.translatePath('special://home/')
]

for url, extract_path in zip(urls, extract_paths):
    file_name = url.split('/')[-1].split('?')[0]
    zip_path = xbmcvfs.translatePath(os.path.join(extract_path, file_name))

    with urllib.request.urlopen(url) as response, open(zip_path, 'wb') as out_file:
        shutil.copyfileobj(response, out_file)

    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)

    os.remove(zip_path)
    
    os.system('kill $(ps | busybox grep org.xbmc.kodi | busybox awk "{ print $2 }")')
